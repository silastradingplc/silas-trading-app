# Silas Trading PLC Flutter starter

This is an interactive UI prototype for the Silas Trading PLC app.

## Included
- Navy and gold brand styling and an S monogram placeholder
- English / Amharic language toggle (initial UI strings)
- Home screen and four business divisions
- Inquiry form with local validation (demo only; no data is transmitted)
- Administration dashboard preview
- Company contact details

## Run locally
1. Install Flutter SDK and Android Studio.
2. From this directory run:
   flutter pub get
   flutter run
3. Select an Android emulator or connected device.

## Important: prototype, not production
The app currently has no live backend, database, authentication, supplier portal, document upload, push notifications, or real admin permissions. The inquiry form only validates fields locally and does not submit data. Do not collect real customer or medical documents with this prototype.

## Next engineering tasks
1. Agree the final logo and app name.
2. Build NestJS API + PostgreSQL database and migrations.
3. Add secure customer and employee authentication with role-based access.
4. Connect product, inquiry, quotation and supplier APIs.
5. Add full Amharic translations and review them with a fluent speaker.
6. Implement privacy policy, terms, data retention and security controls.
7. Test on real Android and iOS devices.
8. Configure signing and store metadata.

## Store builds
Android release: `flutter build appbundle`
iOS release: `flutter build ipa` (requires macOS and Xcode, plus Apple signing setup).

Suggested reverse-domain application ID (confirm domain ownership before use):
`com.silastradingplc.app`

The company should own all developer accounts, source repositories, signing keys and hosting accounts.
