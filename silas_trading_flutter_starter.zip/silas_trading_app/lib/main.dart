
import 'package:flutter/material.dart';

void main() => runApp(const SilasTradingApp());

const navy = Color(0xFF101D36);
const gold = Color(0xFFD9B66B);
const pale = Color(0xFFF4F6F9);

class SilasTradingApp extends StatefulWidget {
  const SilasTradingApp({super.key});
  @override
  State<SilasTradingApp> createState() => _SilasTradingAppState();
}

class _SilasTradingAppState extends State<SilasTradingApp> {
  bool amharic = false;
  int tab = 0;

  String tr(String en, String am) => amharic ? am : en;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(tr: tr, onBrowse: (i) => setState(() => tab = 1)),
      DivisionsPage(tr: tr, onInquiry: () => setState(() => tab = 2)),
      InquiryPage(tr: tr),
      const AdminPreviewPage(),
      AboutPage(tr: tr),
    ];
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Silas Trading PLC',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: pale,
        colorScheme: ColorScheme.fromSeed(seedColor: navy, primary: navy, secondary: gold),
        appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
        inputDecorationTheme: InputDecorationTheme(
          filled: true, fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
      home: Scaffold(
        appBar: AppBar(
          title: const BrandMark(),
          actions: [
            TextButton(
              onPressed: () => setState(() => amharic = !amharic),
              child: Text(amharic ? 'EN' : 'አማ', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
        body: pages[tab],
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: [
            NavigationDestination(icon: const Icon(Icons.home_outlined), label: tr('Home', 'መነሻ')),
            NavigationDestination(icon: const Icon(Icons.grid_view_outlined), label: tr('Explore', 'ይመልከቱ')),
            NavigationDestination(icon: const Icon(Icons.request_quote_outlined), label: tr('Inquiry', 'ጥያቄ')),
            NavigationDestination(icon: const Icon(Icons.dashboard_outlined), label: tr('Admin', 'አስተዳደር')),
            NavigationDestination(icon: const Icon(Icons.business_outlined), label: tr('Company', 'ስለ እኛ')),
          ],
        ),
      ),
    );
  }
}

class BrandMark extends StatelessWidget {
  const BrandMark({super.key});
  @override
  Widget build(BuildContext context) => Row(children: [
    Container(width: 34, height: 34, decoration: BoxDecoration(color: gold, borderRadius: BorderRadius.circular(10)),
      child: const Center(child: Text('S', style: TextStyle(color: navy, fontSize: 24, fontWeight: FontWeight.w900)))),
    const SizedBox(width: 10),
    const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('SILAS TRADING', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: .8, fontSize: 14)),
      Text('PLC  •  GLOBAL BUSINESS', style: TextStyle(color: gold, fontSize: 9, letterSpacing: 1)),
    ]),
  ]);
}

typedef Translator = String Function(String, String);

class HomePage extends StatelessWidget {
  final Translator tr;
  final ValueChanged<int> onBrowse;
  const HomePage({super.key, required this.tr, required this.onBrowse});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(24)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('GLOBAL TRADE. CONNECTED OPPORTUNITIES.', style: TextStyle(color: gold, fontSize: 10, letterSpacing: 1.2)),
        const SizedBox(height: 14),
        Text(tr('Your Global Business Partner', 'የእርስዎ ዓለም አቀፍ የንግድ አጋር'),
          style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        Text(tr('Discover products, source supplies and connect with our team.', 'ምርቶችን ያግኙ፣ አቅርቦቶችን ይፈልጉ እና ከቡድናችን ጋር ይገናኙ።'),
          style: const TextStyle(color: Colors.white70, height: 1.4)),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: () => onBrowse(1), icon: const Icon(Icons.explore), label: Text(tr('Explore our services', 'አገልግሎቶቻችንን ይመልከቱ')),
          style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: navy)),
      ]),
    ),
    const SizedBox(height: 22),
    Text(tr('Our business divisions', 'የንግድ ክፍሎቻችን'), style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.16,
      children: [
        DivisionTile(icon: Icons.storefront, title: tr('Trading', 'ንግድ'), subtitle: tr('Products & wholesale', 'ምርቶች እና ጅምላ')),
        DivisionTile(icon: Icons.local_shipping_outlined, title: tr('Import & Export', 'አስመጪ እና ላኪ'), subtitle: tr('Sourcing & logistics', 'ግዢ እና ሎጂስቲክስ')),
        DivisionTile(icon: Icons.medical_services_outlined, title: tr('Pharmaceuticals', 'መድኃኒቶች'), subtitle: tr('Licensed buyer inquiries', 'የተፈቀዱ ገዢዎች ጥያቄ')),
        DivisionTile(icon: Icons.handshake_outlined, title: tr('Business Services', 'የንግድ አገልግሎቶች'), subtitle: tr('Partnerships', 'አጋርነቶች')),
      ]),
    const SizedBox(height: 18),
    const ContactStrip(),
  ]);
}

class DivisionTile extends StatelessWidget {
  final IconData icon; final String title; final String subtitle;
  const DivisionTile({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE7EAF0))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, color: gold, size: 29), const SizedBox(height: 10),
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: navy)),
      const SizedBox(height: 4), Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.black54)),
    ]),
  );
}

class DivisionsPage extends StatelessWidget {
  final Translator tr; final VoidCallback onInquiry;
  const DivisionsPage({super.key, required this.tr, required this.onInquiry});
  @override
  Widget build(BuildContext context) {
    final items = [
      ('Trading', 'General products, wholesale sourcing and product availability.', Icons.storefront),
      ('Import & Export', 'International sourcing, export requests and shipping coordination.', Icons.local_shipping),
      ('Pharmaceuticals', 'Medicine and medical-supply inquiries for eligible, licensed buyers.', Icons.medical_services),
      ('Business Services', 'Corporate inquiries, supplier partnerships and business proposals.', Icons.handshake),
    ];
    return ListView(padding: const EdgeInsets.all(18), children: [
      Text(tr('Explore our services', 'አገልግሎቶቻችንን ይመልከቱ'), style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      ...items.map((e) => Card(color: Colors.white, child: ListTile(
        contentPadding: const EdgeInsets.all(14), leading: CircleAvatar(backgroundColor: navy, child: Icon(e.$3, color: gold)),
        title: Text(tr(e.$1, e.$1), style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text(e.$2)),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onInquiry,
      ))),
      const SizedBox(height: 12),
      const Text('Pharmaceutical products and services are subject to applicable licensing and regulatory approval.', style: TextStyle(color: Colors.black54, fontSize: 12)),
    ]);
  }
}

class InquiryPage extends StatefulWidget {
  final Translator tr;
  const InquiryPage({super.key, required this.tr});
  @override
  State<InquiryPage> createState() => _InquiryPageState();
}
class _InquiryPageState extends State<InquiryPage> {
  final form = GlobalKey<FormState>();
  final name = TextEditingController(), email = TextEditingController(), country = TextEditingController(), details = TextEditingController();
  String division = 'Trading';
  bool sent = false;
  @override
  void dispose() { name.dispose(); email.dispose(); country.dispose(); details.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Text(widget.tr('Request a quotation', 'የዋጋ ጥያቄ ያቅርቡ'), style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    Text(widget.tr('Tell us what you need. Our team will contact you.', 'የሚፈልጉትን ይግለጹ። ቡድናችን ያገኝዎታል።'), style: const TextStyle(color: Colors.black54)),
    const SizedBox(height: 18),
    if (sent) Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.green.shade50, borderRadius: BorderRadius.circular(12)), child: const Text('Demo only: inquiry form validated. Connect the backend to submit and receive a reference number.')),
    Form(key: form, child: Column(children: [
      DropdownButtonFormField<String>(value: division, decoration: const InputDecoration(labelText: 'Business division'), items: ['Trading','Import & Export','Pharmaceuticals','Business Services'].map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(), onChanged:(v)=>setState(()=>division=v!)),
      const SizedBox(height: 12),
      _field(name, 'Full name'), const SizedBox(height: 12),
      _field(email, 'Email address', type: TextInputType.emailAddress), const SizedBox(height: 12),
      _field(country, 'Country / delivery destination'), const SizedBox(height: 12),
      _field(details, 'Product, quantity and request details', max: 4),
      const SizedBox(height: 16),
      SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () { if(form.currentState!.validate()) setState(()=>sent=true); }, icon: const Icon(Icons.send), label: const Text('Submit inquiry'))),
    ])),
    const SizedBox(height: 14),
    const Text('This prototype does not transmit or store your information. A secure backend and privacy notice must be added before public release.', style: TextStyle(fontSize: 11, color: Colors.black54)),
  ]);
  Widget _field(TextEditingController c, String label, {TextInputType type = TextInputType.text, int max = 1}) => TextFormField(
    controller: c, keyboardType: type, maxLines: max, decoration: InputDecoration(labelText: label),
    validator: (v) => (v == null || v.trim().isEmpty) ? 'Please enter $label' : null,
  );
}

class AdminPreviewPage extends StatelessWidget {
  const AdminPreviewPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Text('Administration preview', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
    const SizedBox(height: 6),
    const Text('Sample dashboard layout. Secure employee authentication and live database are not connected yet.', style: TextStyle(color: Colors.black54)),
    const SizedBox(height: 18),
    const Row(children: [Expanded(child: MetricCard(label:'New inquiries',value:'12',icon:Icons.mark_email_unread)), SizedBox(width:10), Expanded(child: MetricCard(label:'Open quotes',value:'8',icon:Icons.request_quote))]),
    const SizedBox(height: 12),
    const Row(children: [Expanded(child: MetricCard(label:'Suppliers',value:'6',icon:Icons.local_shipping)), SizedBox(width:10), Expanded(child: MetricCard(label:'Products',value:'24',icon:Icons.inventory_2))]),
    const SizedBox(height: 20),
    const Text('Management modules', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
    ...['Customer inquiries','Product catalog','Supplier applications','Quotation management','Employee access & roles','Reports and audit log'].map((s)=>Card(color:Colors.white,child:ListTile(leading:const Icon(Icons.chevron_right),title:Text(s)))),
  ]);
}
class MetricCard extends StatelessWidget {
  final String label,value; final IconData icon;
  const MetricCard({super.key,required this.label,required this.value,required this.icon});
  @override
  Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:gold),const SizedBox(height:10),Text(value,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold,color:navy)),Text(label,style:const TextStyle(fontSize:11,color:Colors.black54))]));
}

class AboutPage extends StatelessWidget {
  final Translator tr;
  const AboutPage({super.key, required this.tr});
  @override
  Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
    const BrandMark(), const SizedBox(height:20),
    Text(tr('Your Global Business Partner','የእርስዎ ዓለም አቀፍ የንግድ አጋር'),style:Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.bold)),
    const SizedBox(height:12),
    const Text('Silas Trading PLC connects customers and business partners with trading, sourcing, import/export and approved pharmaceutical opportunities.'),
    const SizedBox(height:20), const ContactStrip(),
    const SizedBox(height:20), const Text('Website: silastradingplc.com'),
    const Text('Email: silastradingplc@gmail.com'),
    const Text('Phone: +251 961 497 777'),
  ]);
}
class ContactStrip extends StatelessWidget {
  const ContactStrip({super.key});
  @override
  Widget build(BuildContext context)=>Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text('CONTACT SILAS TRADING PLC',style:TextStyle(fontWeight:FontWeight.bold,color:navy,letterSpacing:.5)),
    SizedBox(height:10), Row(children:[Icon(Icons.email_outlined,size:18,color:gold),SizedBox(width:8),Expanded(child:Text('silastradingplc@gmail.com'))]),
    SizedBox(height:7),Row(children:[Icon(Icons.phone_outlined,size:18,color:gold),SizedBox(width:8),Text('+251 961 497 777')]),
    SizedBox(height:7),Row(children:[Icon(Icons.language,size:18,color:gold),SizedBox(width:8),Text('silastradingplc.com')]),
  ]));
}
